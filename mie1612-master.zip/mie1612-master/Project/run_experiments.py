import Project.Project_Extensive_Form as EF
import random
import csv

# scenarios
TIME_LIMIT = 1800
num_scenarios = [x*25 for x in range(1,7)]
num_trials = 10


# results file, in case it doesn't exit, create it
file_name = "results.csv"
open(file_name, 'a').close()

for num_scenario in num_scenarios: # our instances
    for i in range(num_trials): # our trials at each instance
        # keep seed same for each method in one trial
        seed = random.randint(1, 117)

        # run extensive form
        [objVal, status, gap, runtime] = EF.run_extensive_form(num_scenario, seed, TIME_LIMIT)
        with open(file_name, 'a',) as myfile:
            wr = csv.writer(myfile, quoting=csv.QUOTE_ALL)
            wr.writerow([str(num_scenario)+'_'+str(i), 'EF', objVal, status, gap, runtime])

        # run benders
