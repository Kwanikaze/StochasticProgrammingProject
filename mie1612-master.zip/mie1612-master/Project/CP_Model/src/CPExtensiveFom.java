import ilog.cp.*;
import ilog.concert.*;
import ilog.cplex.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.*;

public class CPExtensiveFom {
    private static ArrayList<TreeMap<String,Double>> import_data(String filepath) throws  Exception {
        ArrayList<TreeMap<String,Double>> list = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filepath));
        String line;
        TreeMap<String, Double> treeMap = new TreeMap<>();
        while((line = br.readLine()) != null) {
            // Check if line is blank, if so we should create a new HashMap to add to our list as it's for a new data
            // parameter

            if (line.equals("")) {
                list.add(treeMap);
                treeMap = new TreeMap<>();
                continue;
            }

            String[] parts = line.split(" ");
            String key;
            if(parts.length > 2)
                key = String.join("", Arrays.copyOfRange(parts, 0, parts.length-1));
            else
                key = parts[0];
            // Create composite hashmap
            treeMap.put(key, Double.parseDouble(parts[parts.length-1]));
        }

        return list;
    }

    private static String[] build_sets(String prefix, int size) {
        String[] arr = new String[size];
        for(int i = 0; i < size; i++){
            arr[i] = prefix + i;
        }
        return arr;
    }
    public static void main (String[] args) throws Exception {
        System.out.println("*".repeat(75));

        // Import data from data.txt and build treemaps (sorted for debugging)
        ArrayList<TreeMap<String,Double>> data = import_data("../data.txt");
        //System.out.println(data);

        TreeMap<String,Double> p_t = data.get(0);
        TreeMap<String,Double> b_ijt = data.get(1);
        TreeMap<String,Double> c_ikt = data.get(2);
        TreeMap<String,Double> d_jkmt = data.get(3);
        TreeMap<String,Double> e_it = data.get(4);
        TreeMap<String,Double> a_it = data.get(5);
        TreeMap<String,Double> f_lt = data.get(6);
        TreeMap<String,Double> ecap_mt = data.get(7);
        TreeMap<String,Double> hcap_lt = data.get(8);
        TreeMap<String,Double> wx = data.get(9);


        /* Warning these are hard coded here
        // enod, hnode, , u, v, wx,
         */
        double enod = 10e6;
        double hnod = 10e6;
        int u = 5;
        int v = 10;
        int num_locations = 80;

        int num_scenarios = p_t.size();

        //Build sets
        String[] T = build_sets("T", num_scenarios);
        String[] I = build_sets("I", num_locations);
        String[] J = build_sets("J", 20);
        String[] K = build_sets("K", 10);
        String[] L = {"MCW", "ICW", "ICU"};
        String[] M = {"G","A"};


        // TODO if m == 0, ground otherwise m==1 is air


        IloCP cp = new IloCP();

        // Create variables
        // y variable binary, j
        IloIntVar[] y = new IloIntVar[J.length];
        for (int j = 0; j < J.length; j++) {
            y[j] = cp.boolVar("y_" + j);
        }
        // z variable binary, k
        IloIntVar[] z = new IloIntVar[K.length];
        for (int k = 0; k < K.length; k++) {
            z[k] = cp.boolVar("z_" + k);
        }
        // x variable flow:
        IloIntVar[][][][][][] x = new IloIntVar[I.length][J.length][K.length][L.length][M.length][T.length];
        for (int i = 0; i < I.length; i++) {
            for (int j = 0; j < J.length; j++) {
                for (int k = 0; k < K.length; k++) {
                    for (int l = 0; l < L.length; l++) {
                        for (int m = 0; m < M.length; m++) {
                            for (int t = 0; t < T.length; t++) {
                                x[i][j][k][l][m][t] = cp.intVar(0, Integer.MAX_VALUE,"x_" + i + "_" + j + "_" + k + "_" + l + "_" + m + "_" + t);
                            }
                        }
                    }
                }
            }
        }


        // Create objective
        IloLinearNumExpr objective = cp.linearNumExpr();
        for (int i = 0; i < I.length; i++) {
            for (int j = 0; j < J.length; j++) {
                for (int k = 0; k < K.length; k++) {
                    for (int l = 0; l < L.length; l++) {
                        for (int m = 0; m < M.length; m++) {
                            for (int t = 0; t < T.length; t++) {
                                double coeff = p_t.get(T[t])*a_it.get(I[i]+T[t])*(((double) b_ijt.get(I[i]+J[j]+T[t]) + c_ikt.get(I[i]+K[k]+T[t])) / (double) d_jkmt.get(J[j]+K[k]+M[m]+T[t]));
                                objective.addTerm(x[i][j][k][l][m][t], coeff);
                            }
                        }
                    }
                }
            }
        }

        cp.add(cp.minimize(objective));


        // Create constraints
        // Constraint 1
        for (int i = 0; i < I.length; i++) {
            for (int t = 0; t < T.length; t++) {
                IloLinearIntExpr expr = cp.linearIntExpr();

                for (int j = 0; j < J.length; j++) {
                    for (int k = 0; k < K.length; k++) {
                        for (int l = 0; l < L.length; l++) {
                            for (int m = 0; m < M.length; m++) {
                                expr.addTerm(x[i][j][k][l][m][t], 1);
                            }
                        }
                    }
                }

                cp.add(cp.eq(expr, e_it.get(I[i]+T[t]), "Constraint 1"));
            }
        }

        // Constraint 2
        for (int m = 0; m < M.length; m++) {
            for (int t = 0; t < T.length; t++) {
                IloLinearIntExpr expr = cp.linearIntExpr();

                for (int i = 0; i < I.length; i++) {
                    for (int j = 0; j < J.length; j++) {
                        for (int k = 0; k < K.length; k++) {
                            for (int l = 0; l < L.length; l++) {
                                expr.addTerm(x[i][j][k][l][m][t], 1);
                            }
                        }
                    }
                }

                cp.add(cp.le(expr, ecap_mt.get(M[m]+T[t]), "Constraint 2"));
            }
        }

        // Constraint 3
        for (int l = 0; l < L.length; l++) {
            for (int t = 0; t < T.length; t++) {

                IloLinearIntExpr expr = cp.linearIntExpr();
                for (int i = 0; i < I.length; i++) {
                    for (int j = 0; j < J.length; j++) {
                        for (int k = 0; k < K.length; k++) {
                            for (int m = 0; m < M.length; m++) {
                                expr.addTerm(x[i][j][k][l][m][t], 1);
                            }
                        }
                    }
                }
                cp.add(cp.le(expr, hcap_lt.get(L[l]+T[t]), "Constraint 3"));
            }
        }

        // Constraint 4
        for (int j = 0; j < J.length; j++) {
            for (int t = 0; t < T.length; t++) {

                IloLinearIntExpr expr = cp.linearIntExpr();
                for (int i = 0; i < I.length; i++) {
                    for (int k = 0; k < K.length; k++) {
                        for (int l = 0; l < L.length; l++) {
                            for (int m = 0; m < M.length; m++) {
                                expr.addTerm(x[i][j][k][l][m][t], 1);
                            }
                        }
                    }
                }
                expr.addTerm(y[j], (int) Math.round(-enod));
                cp.add(cp.le(expr, 0, "Constraint 4"));

            }
        }

        // Constraint 5
        for (int k = 0; k < K.length; k++) {
            for (int t = 0; t < T.length; t++) {

                IloLinearIntExpr expr = cp.linearIntExpr();
                for (int i = 0; i < I.length; i++) {
                    for (int j = 0; j < J.length; j++) {
                        for (int l = 0; l < L.length; l++) {
                            for (int m = 0; m < M.length; m++) {
                                expr.addTerm(x[i][j][k][l][m][t], 1);
                            }
                        }
                    }
                }
                expr.addTerm(z[k], (int) Math.round(-hnod));
                cp.add(cp.le(expr, 0, "Constraint 5"));

            }
        }

        // Constraint 6
        for (int t = 0; t < T.length; t++) {

            IloLinearIntExpr expr = cp.linearIntExpr();
            for (int i = 0; i < I.length; i++) {
                for (int j = 0; j < J.length; j++) {
                    for (int k = 0; k < K.length; k++) {
                        for (int l = 0; l < L.length; l++) {
                            for (int m = 0; m < M.length; m++) {
                                if(m == 0) { // If ground type!
                                    expr.addTerm(x[i][j][k][l][m][t], 10); // Multiply by 10 to create int from wx %
                                }
                                expr.addTerm(x[i][j][k][l][m][t], (int) Math.round(-10*wx.get(T[t])));
                            }
                        }
                    }
                }
            }
            cp.add(cp.ge(expr, 0, "Constraint 6"));

        }


        // Constraint 7
        IloLinearIntExpr expr = cp.linearIntExpr();
        for (int j = 0; j < J.length; j++) {
            expr.addTerm(y[j],1);
        }
        cp.add(cp.eq(expr,v,"Constraint 7"));

        // Constraint 8
        expr = cp.linearIntExpr();
        for (int k = 0; k < K.length; k++) {
            expr.addTerm(z[k],1);
        }
        cp.add(cp.eq(expr,u,"Constraint 8"));

        // Constraint 9 f_lt new
        for (int l = 0; l < L.length; l++) {
            for (int t = 0; t < T.length; t++) {
                expr = cp.linearIntExpr();

                for (int i = 0; i < I.length; i++) {
                    for (int j = 0; j < J.length; j++) {
                        for (int k = 0; k < K.length; k++) {
                            for (int m = 0; m < M.length; m++) {
                                expr.addTerm(x[i][j][k][l][m][t], 1);
                            }
                        }
                    }
                }

                cp.add(cp.eq(expr, f_lt.get(L[l]+T[t]), "Constraint 9"));
            }
        }




        // Solve
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        System.out.println("Started running optimizer: " + formatter.format(date));
        cp.setParameter(IloCP.DoubleParam.TimeLimit, 1800);
        //cp.exportModel("CP_model.cpo");

        boolean success = cp.solve();

        double runTime = cp.getInfo(IloCP.DoubleInfo.SolveTime);

        if (success) {
            System.out.println("Optimizer status: " + cp.getStatus());
            System.out.println("Optimizer gap: " + cp.getObjGap());
            System.out.println("Optimizer objective: " + cp.getObjValue());
        }
        else {
            if (cp.refineConflict()) {
                // Model is infeasible
                cp.writeConflict();
            }
        }

        System.out.println("Optimizer run time (s): " + runTime);
    }



}
