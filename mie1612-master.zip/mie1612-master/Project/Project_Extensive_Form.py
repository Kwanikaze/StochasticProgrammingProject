from gurobipy import *


def run_extensive_form(scenarios, seed, TIME_LIMIT):
    import Project.data_generation as d
    Data = d.data(scenarios, seed)

    num_scenarios = Data.num_scenarios
    num_locations = Data.num_locations
    # Build Sets
    T = ['T' + str(num) for num in list(range(0, num_scenarios))]
    I = ['I' + str(num) for num in list(range(0, num_locations))]
    J = ['J' + str(num) for num in list(range(0, 20))]
    K = ['K' + str(num) for num in list(range(0, 10))]
    L = Data.Lset
    M = Data.Mset

    a = Data.a_it  # injury severity (i,t)
    b = Data.b_ijt  # distance injury to evac (i,j,t)
    c = Data.c_ikt  # distance injury to hospital (i,k,t)
    d = Data.d_jkmt  # speed (j,k,m,t)
    e = Data.e_it  # total people injured (i,t)
    f = Data.f_lt  # number patient bed req (l,t)
    ecap = Data.ecap_mt  # m transport capacity (m,t)
    hcap = Data.hcap_lt  # hospital bed type capacity (l,t)
    enod = Data.enod  # evac capacity (j,t)
    hnod = Data.hnod  # hospital capacity (k,t)
    u = Data.u  # max num hospital sites to open
    v = Data.v  # max num evac sites to open
    wx = Data.wx_scen  # proportion ground evac req (t)
    p = Data.p_t  # probability of each scenario

    c_ForAllScen = [p[t] * a[i, t] * ((b[i, j, t] + c[i, k, t]) / d[j, k, m, t])
                    for i in I for j in J for k in K for l in L for m in M for t in T]

    # Build model
    m = Model("2SP_ExtForm")

    # First stage decison variables
    y = m.addVars(J, vtype=GRB.BINARY, name='y')  # select evac site
    z = m.addVars(K, vtype=GRB.BINARY, name='z')  # select hospital site

    # Second stage decision variables
    x = m.addVars(I, J, K, L, M, T, obj=c_ForAllScen, name='x')

    m.modelSense = GRB.MINIMIZE

    # constraints
    m.addConstrs(
        (x.sum(i, '*', '*', '*', '*', t) == e[i, t] for i in I for t in T), name='EvacAll')

    m.addConstrs(
        (x.sum('*', '*', '*', '*', m, t) <= ecap[m, t] for m in M for t in T), name='CapEvac')

    # check why [i][t] thought it was [l][t]
    m.addConstrs(
        (x.sum('*', '*', '*', l, '*', t) <= hcap[l, t] for l in L for t in T), name='CapHospital')

    m.addConstrs(
        (x.sum('*', j, '*', '*', '*', t) <= enod * y[j] for j in J for t in T), name='CapEvacFlow')

    m.addConstrs(
        (x.sum('*', '*', k, '*', '*', t) <= hnod * z[k] for k in K for t in T), name='CapHospitalFlow')

    m.addConstr((y.sum('*') == v), name='CapEvacSites')

    m.addConstr((z.sum('*') == u), name='CapHospitalSites')

    m.addConstrs((x.sum('*', '*', '*', '*', 'G', t) >= (wx[t] * x.sum('*', '*', '*', '*', '*', t)) for t in T),
                 name='GroundTransportProportion')

    m.addConstrs((x.sum('*', '*', '*', l, '*', t) == f[l, t] for l in L for t in T), name='new')
    m.Params.TIME_LIMIT = TIME_LIMIT
    m.Params.Threads = 1
    m.optimize()


    return [m.objVal, m.Status, m.MIPGap, m.Runtime]
    # print('SOLUTION:')
    # for j in J:
    #     if y[j].x > 0.99:
    #         print(y[j].VarName + str(y[j].x))
    # for k in K:
    #     if z[k].x > 0.99:
    #         print(z[k].VarName + str(z[k].x))

    # for i in I:
    #     for j in J:
    #         for k in K:
    #             for l in L:
    #                 for m in M:
    #                     for t in T:
    #                         if x[i][j][k][l][m][t].x > 0.0:
    #                             print(x[i][j][k][l][m][t].VarName + str(x[i][j][k][l][m][t].x))

