from gurobipy import *
import numpy as np

##### Building the Data #####

# Read the data from file

CutViolationTolerance = 0.0001
OptionForSubproblem = 1  # 0 ==> Use Primal, 1==> Use Dual

Delta = 3 # trust region tolerance
mu = 0.1
eps = 10e-6
c = [1, 2, 2, 1]  # first stage costs in obj
c_sp = [1, 2, 1, 2]  # subproblem costs
omega = [[1, 1 / 3], [4, 1], [5 / 2, 2 / 3], [1, 1]]
SP_b = [7, 4, 5, 8]  # rhs of SP without assignment
nS = len(omega)  # the number of scenarios
p = [1.0 / nS] * nS  # scenario probabilities (assuming equally likely scenarios)

# Build sets
X_set = range(len(c))
Y_set = range(len(c_sp))
S = range(nS)  # omega


def ModifyAndSolveSP(s, x_sol):
    # Modify constraint rhs
    SP_Constraints[0].rhs = SP_b[0] - omega[s][0] * x_sol[0] - x_sol[1]
    SP_Constraints[1].rhs = SP_b[1] - omega[s][1] * x_sol[0] - x_sol[1]
    SP_Constraints[2].rhs = SP_b[2] + 0.5 * omega[s][0] * x_sol[0] - x_sol[2]
    SP_Constraints[3].rhs = SP_b[3] - 0.5 * omega[s][1] * x_sol[0] - omega[s][0] * x_sol[3]

    SP.update()

    # Solve and get the DUAL solution
    SP.optimize()

    pi_sol = [SP_Constraints[i].Pi for i in range(len(SP_Constraints))]

    SPobj = SP.objVal

    # print("Subproblem " + str(s))
    # print('SPobj: %g' % SPobj)
    # print("pi_sol: " + str(pi_sol))

    # Check whether a violated Benders cut is found
    CutFound = False
    if (nsol[s] < SPobj - CutViolationTolerance):  # Found Benders cut is violated at the current master solution
        CutFound = True

    return SPobj, CutFound, pi_sol


##### Build the master problem #####
MP = Model("MP")
MP.Params.outputFlag = 0  # turn off output
MP.Params.method = 1  # dual simplex

# First-stage variables:
x = MP.addVars(X_set, obj=c, name='x')
n = MP.addVars(S, obj=p, name='n')
# Note: Default variable bounds are LB = 0 and UB = infinity

MP.modelSense = GRB.MINIMIZE

##### Build the subproblem(s) #####
# Build Primal SP
SP = Model("SP")
y = SP.addVars(Y_set, obj=c_sp, name='y')

SP_Constraints = []
# Demand constraints
SP_Constraints.append(SP.addConstr((y[0] >= 0), "SP_C_1"))
SP_Constraints.append(SP.addConstr((y[1] >= 0), "SP_C_2"))
SP_Constraints.append(SP.addConstr((y[2] >= 0), "SP_C_3"))
SP_Constraints.append(SP.addConstr((y[3] >= 0), "SP_C_4"))
# NOTE: We will set the rhs of the constraints inside the loop later, so for now initialize them using your favorite number!

SP.modelSense = GRB.MINIMIZE
SP.Params.outputFlag = 0

##### Benders Loop #####
CutFound = True
NoIters = 0
BestUB = GRB.INFINITY

# trust region intialize
x_t = [0, 0, 0, 0]
nsol = [0, 0, 0, 0]
y_t = x_t
UB = np.dot(c, x_t)
# get f(y_t) and subgradient info
for s in S:
    Qvalue, CutFound_s, pi_sol = ModifyAndSolveSP(s, y_t)

    UB += p[s] * Qvalue

    if (CutFound_s):
        CutFound = True
        # Dual has 4 variables corresponding to the 4 Primal constraints, eta_s -b^t pi >=0
        expr = LinExpr(
            n[s] - (SP_b[0] - omega[s][0] * x[0] - x[1]) * pi_sol[0]
            - (SP_b[1] - omega[s][1] * x[0] - x[1]) * pi_sol[1]
            - (SP_b[2] + 0.5 * omega[s][0] * x[0] - x[2]) * pi_sol[2]
            - (SP_b[3] - 0.5 * omega[s][1] * x[0] - omega[s][0] * x[3]) * pi_sol[3])
        MP.addConstr(expr >= 0)
        # print("CUT: " + str(expr) + " >= 0")

f_y_t = UB
while (CutFound):
    NoIters += 1
    CutFound = False

    # add trust region constraint
    trust_region1 = []
    trust_region2 = []
    for i in X_set:
        trust_region1.append(MP.addConstr((x[i] - x_t[i] <= Delta), "trust region1 " + str(i)))
        trust_region2.append(MP.addConstr((x_t[i] - x[i] <= Delta), "trust region2 " + str(i)))


    # Solve MP
    MP.update()
    MP.optimize()
    MP.remove(trust_region1)  # remove, incase we change the trust region constraint next interation
    MP.remove(trust_region2)

    # Get MP solution
    m_t_y_t_plusone = MP.objVal  # m_t_of_y_t_+1
    # print('MPobj: %g' % MPobj)

    y_t_plusone = [x[i].x for i in X_set]
    nsol = [n[s].x for s in S]

    # print("xsol: " + str(y_t_plusone))
    # print("nsol: " + str(nsol))

    UB = np.dot(c, x_t)

    for s in S:
        Qvalue, CutFound_s, pi_sol = ModifyAndSolveSP(s, x_t)

        UB += p[s] * Qvalue

        # if (CutFound_s):
        #     CutFound = True
        #     # Dual has 4 variables corresponding to the 4 Primal constraints, eta_s -b^t pi >=0
        #     expr = LinExpr(
        #         n[s] - (SP_b[0] - omega[s][0] * x[0] - x[1]) * pi_sol[0]
        #              - (SP_b[1] - omega[s][1] * x[0] - x[1]) * pi_sol[1]
        #              - (SP_b[2] + 0.5 * omega[s][0] * x[0] - x[2]) * pi_sol[2]
        #              - (SP_b[3] - 0.5 * omega[s][1] * x[0] - omega[s][0] * x[3]) * pi_sol[3])
        #     MP.addConstr(expr >= 0) # step 4 update
        #     print("CUT: " + str(expr) + " >= 0")

    if (UB < BestUB):
        BestUB = UB
    # print("UB: " + str(UB) + "\n")
    #####print("BestUB: " + str(BestUB) + "\n")

    # compute predicted decrease
    f_x_t = UB
    delta = UB - m_t_y_t_plusone  # f(x^t) - m^t(y^(t+1))
    if delta <= eps:  # optimal!
        break

    # step 4 subproblems
    UB = np.dot(c, y_t_plusone)

    for s in S:
        Qvalue, CutFound_s, pi_sol = ModifyAndSolveSP(s, y_t_plusone)

        UB += p[s] * Qvalue

        if (CutFound_s):
            CutFound = True
            # Dual has 4 variables corresponding to the 4 Primal constraints, eta_s -b^t pi >=0
            expr = LinExpr(
                n[s] - (SP_b[0] - omega[s][0] * x[0] - x[1]) * pi_sol[0]
                - (SP_b[1] - omega[s][1] * x[0] - x[1]) * pi_sol[1]
                - (SP_b[2] + 0.5 * omega[s][0] * x[0] - x[2]) * pi_sol[2]
                - (SP_b[3] - 0.5 * omega[s][1] * x[0] - omega[s][0] * x[3]) * pi_sol[3])
            MP.addConstr(expr >= 0)  # step 4 update
            # print("CUT: " + str(expr) + " >= 0")

    if (UB < BestUB):
        BestUB = UB

    f_y_t_plusone = UB
    if f_x_t - f_y_t_plusone >= mu * delta:
        x_t = y_t_plusone
    else:
        x_t = x_t

print('\nOptimal Solution:')
print('MPobj: %g' % f_y_t_plusone)
print("xsol: " + str(y_t_plusone))
print("nsol: " + str(nsol))
print("NoIters: " + str(NoIters))
