import numpy as np
from gurobipy import *

'''
Returns the objective funtion of the master problem given a feasible assignment of x variables (4 xi's and 4yi's)
'''


def evaluate_fx(assignment):
    coeff = np.array([1, 2, 2, 1, 1, 2, 1, 2])  # don't need expectation of y vars as equal prob
    return np.dot(assignment, coeff)


def solve_sp(x, omega):
    sp = Model("SP-" + str(x) + "-" + str(omega))
    y_var = sp.addVars(Y, obj=np.array[1, 2, 1, 2], name='y')
    sp.modelSense = GRB.MINIMIZE
    sp.addConstr((omega[0] * x[0] + x[1] + y_var[0]) >= 7, name='c1')
    sp.addConstr((omega[1] * x[0] + x[1] + y_var[1]) >= 4, name='c2')
    sp.addConstr((-0.5 * omega[0] * x[0] + x[2] + y_var[2]) >= 5, name='c3')
    sp.addConstr((0.5 * omega[1] * x[0] + omega[0] * x[3] + y_var[3]) >= 8, name='c4')
    sp.optimize()

    # return dual variables for subgradient cuts
    return sp.getAttr("Pi")  # todo return cuts


# initialization
X = range(3)
Y = range(3)
x = np.zeros(len(X))
y = x
x_last = x
Delta = 3
mu = 0.1
t = 1
eps = 10e-6
omega = [(1, 1 / 3), (4, 1), (5 / 2, 2 / 3)]
c = np.array([1, 2, 2, 1])


def subgradient_cut(duals):
    cut = c
    for i in range(len(omega)):
        cut = cut - 1 / len(omega) * np.transpose(np.array(
            [[omega[i][0], 1, 0, 0], [omega[i][1], 1, 0, 0], [-0.5 * omega[i][0], 0, 1, 0],
             [0.5 * omega[i][1], 0, 0, 1]])) * duals[i]
    return cut


# evaluate f(y') and subgradient information at y1


# Create mt(x), our master problem
m = Model("MP")
theta = m.addVar(obj=1.0, name="theta")
x_var = m.addVars(X, name="x")
m.addConstr((x[0] + x[1]) <= 4, "c1")
# trust region constraint
m.addConstr((np.absolute(x - x_last)) <= Delta, "trust region")
# todo first subgradient cut
f_y = evaluate_fx(y)
cuts =  cuts = subgradient_cut(duals)
m.addConstrs((theta >= cuts[i] for i in range(len(cuts))), 'cuts')

# main algorithm
while True:
    m.update()
    # step 1: solve master problem
    m.optimize()
    for i in X:
        y[i] = x_var[i].x

    # step 2: compute predicted decrease
    f_x = evaluate_fx(x)
    delta = f_x - m.getObjective()

    # step 3: optimality check
    if delta < eps:
        break

    # step 4: subproblems
    # compute f(y t+1)
    f_y = evaluate_fx(y)
    # solve sps
    duals = []
    for w in omega:
        duals.append(solve_sp(y, w))
    cuts = subgradient_cut(duals)
    m.addConstrs((theta >= cuts[i] for i in range(len(cuts))), 'cuts')

    if f_x - f_y >= mu*delta:
        x = y
    else:
        pass
    t = t + 1
# TODO print solution
